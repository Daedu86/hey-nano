/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */

// polyfills are now bundled with all other dependencies
import './third_party/index.js';
